#!/usr/bin/env python2.7
# pylint # {{{
# vim: tw=100 foldmethod=marker
# pylint: disable=bad-continuation, invalid-name, superfluous-parens
# pylint: disable=bad-whitespace, mixed-indentation
# pylint: disable=redefined-outer-name, logging-not-lazy, logging-format-interpolation
# pylint: disable=missing-docstring, trailing-whitespace, trailing-newlines, too-few-public-methods
# }}}

import sys
import os
import re
import json
import requests
import configargparse

def remove_quotes(data):# {{{
    return data.lstrip('"').lstrip("'").rstrip('"').rstrip("'")
# }}}
def parseOptions():# {{{
    '''Parse the commandline options'''

    path_of_executable = os.path.realpath(sys.argv[0])
    folder_of_executable = os.path.split(path_of_executable)[0]
    full_name_of_executable = os.path.split(path_of_executable)[1]
    name_of_executable = full_name_of_executable.rstrip('.py')

    config_files = [os.environ['HOME']+'/.config/%sconf' % name_of_executable,
                    folder_of_executable +'/%s.conf'     % name_of_executable,
                    '/root/configs/%s.conf'              % name_of_executable]

    parser = configargparse.ArgumentParser(
            default_config_files = config_files,
            description='''ldf-interface''', ignore_unknown_config_file_keys=True)

    parser.add_argument('--rest_user',   '-u',             help='username for LDF rest interface')
    parser.add_argument('--rest_passwd', '-p',             help='passwdname for LDF rest interface')
    parser.add_argument('--iss'                  , action="append")
    parser.add_argument('--bwidmOrgId'           , default="hdf")
    parser.add_argument('--base_url'             , default="https://bwidm-test.scc.kit.edu/rest/")
    parser.add_argument('--verify_tls'           , default=True    , action="store_false" , help='disable verify')
    parser.add_argument('--issTranslateExpression', default='{"unity-hdf": "unity.helmholtz-data-federation.de/oauth2",  "kit": "https://oidc.scc.kit.edu/auth/realms/kit"}')
    parser.add_argument(dest='sub_iss'  , help='Content of $REMOTE_USER. For testing use "test-offline" and "test-id"')
    args = parser.parse_args()

    # sanitize some args:
    args.base_url   = args.base_url.rstrip('/')
    args.bwidmOrgId = remove_quotes(args.bwidmOrgId)

    # ensure translation will work as JSON
    try:
        args.issTranslateExpressionJSON = json.loads(args.issTranslateExpression)
        try:
            for key in args.issTranslateExpressionJSON.keys():
                args.issTranslateExpressionJSON[key] = remove_quotes(args.issTranslateExpressionJSON[key])
        except:
            sys.stderr.write('FATAL: issTranslateExpression needs to be a one line json object that lists keys and values: \n')
            sys.stderr.write('{"unity-hdf": "unity.helmholtz-data-federation.de/oauth2", "test": "https://test.com"}')
            sys.stderr.write('Instead you provided "%s"\n' % str(args.issTranslateExpression))
            raise
    except:
        raise

    return args
# }}}

args = parseOptions()

if args.sub_iss == 'test-offline':
    sys.stdout.write('hdf_marcus\n')
    exit(0) 

if args.sub_iss == 'test-id':
    args.sub_iss = "ec0c370f-39a6-4c15-a94e-cf56367e2414@unity.helmholtz-data-federation.de/oauth2" 
# print (args.sub_iss)
externalId = remove_quotes(args.sub_iss)
(sub, iss) = externalId.split('@')
iss = re.sub('^https?://', '', iss)
iss = iss.rstrip('/')

# replace the iss string:
iTE = args.issTranslateExpressionJSON
# print ( json.dumps(iTE, sort_keys=True, indent=4, separators=(',', ': ')))
for key in iTE.keys():
    # in case user provides https?:// in iTE, we just remove it:
    iTE[key] = re.sub('^https?://', '', iTE[key])
    iss = re.sub("%s$"%iTE[key], key, iss)

externalId = args.bwidmOrgId+"_"+sub+"@"+iss

url = args.base_url + '/external-user/find/externalId/' + str(externalId)

resp = requests.get (url, verify=args.verify_tls, auth=(args.rest_user, args.rest_passwd))

if resp.status_code != 200:
    sys.stderr.write('Error %d reading from remote: \n%s\n'% (resp.status_code, str(resp.text)))
    exit(1)

resp_json=resp.json()
try:
    username = resp_json['attributeStore']['urn:oid:0.9.2342.19200300.100.1.1']
    bwIdmOrgId = resp_json['attributeStore']['http://bwidm.de/bwidmOrgId']

    sys.stdout.write('%s_%s\n' % (bwIdmOrgId, username))
except KeyError as e:
    sys.stderr.write('Error interpreting remote json object: Key Error: %s not found\n' % str(e))
    sys.stderr.write('This is the json data received\n')
    sys.stderr.write(json.dumps(resp_json, sort_keys=True, indent=4, separators=(',', ': ')))
    sys.stderr.write('\n')


# Requires:
# python-2.7
# python-configargparse
